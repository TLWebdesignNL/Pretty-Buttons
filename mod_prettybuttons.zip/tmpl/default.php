<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  mod_prettybuttons
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;
//var_dump($data);
if (is_object($data)) :
?>
<div class="d-flex justify-content-center flex-wrap py-2">
<?	foreach($data as $row) :
		if ($row->text) :
?>
			<span class="me-3 small">
				<?php echo ($row->iconclass) ? '<i class="'.$row->iconclass.' pe-2"></i>' : '' ; ?>
				<?php echo ($row->url) ? '<a target="_blank" href="'.$row->url.'">': ''; ?>
					<?php echo $row->text; ?>
				<?php echo ($row->url) ? '</a>': ''; ?>
			</span>
<?php 
		endif; // if $row->text
	endforeach; // foreach $data as $row
?>
</div>
<?php
endif // check if object 
?>
